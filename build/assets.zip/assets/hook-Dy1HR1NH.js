import {
    r as t,
    C as e
} from "./client-DVrblGvH.js";

function a() {
    return t.useContext(e)
}
export {
    a as u
};