import {
    r as J,
    j as Y
} from "./client-DVrblGvH.js";
import {
    c as Vt
} from "./clsx-B-dksMZM.js";
import {
    F as _t
} from "./chevron-right-rLNBw_Rz.js";

function sn(t) {
    return Object.prototype.toString.call(t) === "[object Object]"
}

function Rt(t) {
    return sn(t) || Array.isArray(t)
}

function cn() {
    return !!(typeof window < "u" && window.document && window.document.createElement)
}

function Ot(t, n) {
    const o = Object.keys(t),
        s = Object.keys(n);
    if (o.length !== s.length) return !1;
    const c = JSON.stringify(Object.keys(t.breakpoints || {})),
        r = JSON.stringify(Object.keys(n.breakpoints || {}));
    return c !== r ? !1 : o.every(e => {
        const u = t[e],
            i = n[e];
        return typeof u == "function" ? `${u}` == `${i}` : !Rt(u) || !Rt(i) ? u === i : Ot(u, i)
    })
}

function Gt(t) {
    return t.concat().sort((n, o) => n.name > o.name ? 1 : -1).map(n => n.options)
}

function un(t, n) {
    if (t.length !== n.length) return !1;
    const o = Gt(t),
        s = Gt(n);
    return o.every((c, r) => {
        const e = s[r];
        return Ot(c, e)
    })
}

function Dt(t) {
    return typeof t == "number"
}

function It(t) {
    return typeof t == "string"
}

function yt(t) {
    return typeof t == "boolean"
}

function Ht(t) {
    return Object.prototype.toString.call(t) === "[object Object]"
}

function M(t) {
    return Math.abs(t)
}

function wt(t) {
    return Math.sign(t)
}

function dt(t, n) {
    return M(t - n)
}

function an(t, n) {
    if (t === 0 || n === 0 || M(t) <= M(n)) return 0;
    const o = dt(M(t), M(n));
    return M(o / t)
}

function fn(t) {
    return Math.round(t * 100) / 100
}

function pt(t) {
    return mt(t).map(Number)
}

function z(t) {
    return t[ht(t)]
}

function ht(t) {
    return Math.max(0, t.length - 1)
}

function Mt(t, n) {
    return n === ht(t)
}

function qt(t, n = 0) {
    return Array.from(Array(t), (o, s) => n + s)
}

function mt(t) {
    return Object.keys(t)
}

function $t(t, n) {
    return [t, n].reduce((o, s) => (mt(s).forEach(c => {
        const r = o[c],
            e = s[c],
            u = Ht(r) && Ht(e);
        o[c] = u ? $t(r, e) : e
    }), o), {})
}

function At(t, n) {
    return typeof n.MouseEvent < "u" && t instanceof n.MouseEvent
}

function ln(t, n) {
    const o = {
        start: s,
        center: c,
        end: r
    };

    function s() {
        return 0
    }

    function c(i) {
        return r(i) / 2
    }

    function r(i) {
        return n - i
    }

    function e(i, a) {
        return It(t) ? o[t](i) : t(n, i, a)
    }
    return {
        measure: e
    }
}

function gt() {
    let t = [];

    function n(c, r, e, u = {
        passive: !0
    }) {
        let i;
        if ("addEventListener" in c) c.addEventListener(r, e, u), i = () => c.removeEventListener(r, e, u);
        else {
            const a = c;
            a.addListener(e), i = () => a.removeListener(e)
        }
        return t.push(i), s
    }

    function o() {
        t = t.filter(c => c())
    }
    const s = {
        add: n,
        clear: o
    };
    return s
}

function dn(t, n, o, s) {
    const c = gt(),
        r = 1e3 / 60;
    let e = null,
        u = 0,
        i = 0;

    function a() {
        c.add(t, "visibilitychange", () => {
            t.hidden && l()
        })
    }

    function h() {
        y(), c.clear()
    }

    function d(g) {
        if (!i) return;
        e || (e = g, o(), o());
        const f = g - e;
        for (e = g, u += f; u >= r;) o(), u -= r;
        const b = u / r;
        s(b), i && (i = n.requestAnimationFrame(d))
    }

    function p() {
        i || (i = n.requestAnimationFrame(d))
    }

    function y() {
        n.cancelAnimationFrame(i), e = null, u = 0, i = 0
    }

    function l() {
        e = null, u = 0
    }
    return {
        init: a,
        destroy: h,
        start: p,
        stop: y,
        update: o,
        render: s
    }
}

function pn(t, n) {
    const o = n === "rtl",
        s = t === "y",
        c = s ? "y" : "x",
        r = s ? "x" : "y",
        e = !s && o ? -1 : 1,
        u = h(),
        i = d();

    function a(l) {
        const {
            height: m,
            width: g
        } = l;
        return s ? m : g
    }

    function h() {
        return s ? "top" : o ? "right" : "left"
    }

    function d() {
        return s ? "bottom" : o ? "left" : "right"
    }

    function p(l) {
        return l * e
    }
    return {
        scroll: c,
        cross: r,
        startEdge: u,
        endEdge: i,
        measureSize: a,
        direction: p
    }
}

function ot(t = 0, n = 0) {
    const o = M(t - n);

    function s(a) {
        return a < t
    }

    function c(a) {
        return a > n
    }

    function r(a) {
        return s(a) || c(a)
    }

    function e(a) {
        return r(a) ? s(a) ? t : n : a
    }

    function u(a) {
        return o ? a - o * Math.ceil((a - n) / o) : a
    }
    return {
        length: o,
        max: n,
        min: t,
        constrain: e,
        reachedAny: r,
        reachedMax: c,
        reachedMin: s,
        removeOffset: u
    }
}

function Ut(t, n, o) {
    const {
        constrain: s
    } = ot(0, t), c = t + 1;
    let r = e(n);

    function e(p) {
        return o ? M((c + p) % c) : s(p)
    }

    function u() {
        return r
    }

    function i(p) {
        return r = e(p), d
    }

    function a(p) {
        return h().set(u() + p)
    }

    function h() {
        return Ut(t, u(), o)
    }
    const d = {
        get: u,
        set: i,
        add: a,
        clone: h
    };
    return d
}

function mn(t, n, o, s, c, r, e, u, i, a, h, d, p, y, l, m, g, f, b) {
    const {
        cross: x,
        direction: L
    } = t, D = ["INPUT", "SELECT", "TEXTAREA"], T = {
        passive: !1
    }, E = gt(), v = gt(), I = ot(50, 225).constrain(y.measure(20)), P = {
        mouse: 300,
        touch: 400
    }, A = {
        mouse: 500,
        touch: 600
    }, N = l ? 43 : 25;
    let V = !1,
        _ = 0,
        R = 0,
        Z = !1,
        W = !1,
        q = !1,
        $ = !1;

    function ct(S) {
        if (!b) return;

        function O(C) {
            (yt(b) || b(S, C)) && at(C)
        }
        const j = n;
        E.add(j, "dragstart", C => C.preventDefault(), T).add(j, "touchmove", () => {}, T).add(j, "touchend", () => {}).add(j, "touchstart", O).add(j, "mousedown", O).add(j, "touchcancel", F).add(j, "contextmenu", F).add(j, "click", K, !0)
    }

    function G() {
        E.clear(), v.clear()
    }

    function rt() {
        const S = $ ? o : n;
        v.add(S, "touchmove", k, T).add(S, "touchend", F).add(S, "mousemove", k, T).add(S, "mouseup", F)
    }

    function st(S) {
        const O = S.nodeName || "";
        return D.includes(O)
    }

    function U() {
        return (l ? A : P)[$ ? "mouse" : "touch"]
    }

    function ut(S, O) {
        const j = d.add(wt(S) * -1),
            C = h.byDistance(S, !l).distance;
        return l || M(S) < I ? C : g && O ? C * .5 : h.byIndex(j.get(), 0).distance
    }

    function at(S) {
        const O = At(S, s);
        $ = O, q = l && O && !S.buttons && V, V = dt(c.get(), e.get()) >= 2, !(O && S.button !== 0) && (st(S.target) || (Z = !0, r.pointerDown(S), a.useFriction(0).useDuration(0), c.set(e), rt(), _ = r.readPoint(S), R = r.readPoint(S, x), p.emit("pointerDown")))
    }

    function k(S) {
        if (!At(S, s) && S.touches.length >= 2) return F(S);
        const j = r.readPoint(S),
            C = r.readPoint(S, x),
            H = dt(j, _),
            Q = dt(C, R);
        if (!W && !$ && (!S.cancelable || (W = H > Q, !W))) return F(S);
        const tt = r.pointerMove(S);
        H > m && (q = !0), a.useFriction(.3).useDuration(.75), u.start(), c.add(L(tt)), S.preventDefault()
    }

    function F(S) {
        const j = h.byDistance(0, !1).index !== d.get(),
            C = r.pointerUp(S) * U(),
            H = ut(L(C), j),
            Q = an(C, H),
            tt = N - 10 * Q,
            X = f + Q / 50;
        W = !1, Z = !1, v.clear(), a.useDuration(tt).useFriction(X), i.distance(H, !l), $ = !1, p.emit("pointerUp")
    }

    function K(S) {
        q && (S.stopPropagation(), S.preventDefault(), q = !1)
    }

    function B() {
        return Z
    }
    return {
        init: ct,
        destroy: G,
        pointerDown: B
    }
}

function gn(t, n) {
    let s, c;

    function r(d) {
        return d.timeStamp
    }

    function e(d, p) {
        const l = `client${(p||t.scroll)==="x"?"X":"Y"}`;
        return (At(d, n) ? d : d.touches[0])[l]
    }

    function u(d) {
        return s = d, c = d, e(d)
    }

    function i(d) {
        const p = e(d) - e(c),
            y = r(d) - r(s) > 170;
        return c = d, y && (s = d), p
    }

    function a(d) {
        if (!s || !c) return 0;
        const p = e(c) - e(s),
            y = r(d) - r(s),
            l = r(d) - r(c) > 170,
            m = p / y;
        return y && !l && M(m) > .1 ? m : 0
    }
    return {
        pointerDown: u,
        pointerMove: i,
        pointerUp: a,
        readPoint: e
    }
}

function hn() {
    function t(o) {
        const {
            offsetTop: s,
            offsetLeft: c,
            offsetWidth: r,
            offsetHeight: e
        } = o;
        return {
            top: s,
            right: c + r,
            bottom: s + e,
            left: c,
            width: r,
            height: e
        }
    }
    return {
        measure: t
    }
}

function bn(t) {
    function n(s) {
        return t * (s / 100)
    }
    return {
        measure: n
    }
}

function Sn(t, n, o, s, c, r, e) {
    const u = [t].concat(s);
    let i, a, h = [],
        d = !1;

    function p(g) {
        return c.measureSize(e.measure(g))
    }

    function y(g) {
        if (!r) return;
        a = p(t), h = s.map(p);

        function f(b) {
            for (const x of b) {
                if (d) return;
                const L = x.target === t,
                    D = s.indexOf(x.target),
                    T = L ? a : h[D],
                    E = p(L ? t : s[D]);
                if (M(E - T) >= .5) {
                    g.reInit(), n.emit("resize");
                    break
                }
            }
        }
        i = new ResizeObserver(b => {
            (yt(r) || r(g, b)) && f(b)
        }), o.requestAnimationFrame(() => {
            u.forEach(b => i.observe(b))
        })
    }

    function l() {
        d = !0, i && i.disconnect()
    }
    return {
        init: y,
        destroy: l
    }
}

function yn(t, n, o, s, c, r) {
    let e = 0,
        u = 0,
        i = c,
        a = r,
        h = t.get(),
        d = 0;

    function p() {
        const T = s.get() - t.get(),
            E = !i;
        let v = 0;
        return E ? (e = 0, o.set(s), t.set(s), v = T) : (o.set(t), e += T / i, e *= a, h += e, t.add(e), v = h - d), u = wt(v), d = h, D
    }

    function y() {
        const T = s.get() - n.get();
        return M(T) < .001
    }

    function l() {
        return i
    }

    function m() {
        return u
    }

    function g() {
        return e
    }

    function f() {
        return x(c)
    }

    function b() {
        return L(r)
    }

    function x(T) {
        return i = T, D
    }

    function L(T) {
        return a = T, D
    }
    const D = {
        direction: m,
        duration: l,
        velocity: g,
        seek: p,
        settled: y,
        useBaseFriction: b,
        useBaseDuration: f,
        useFriction: L,
        useDuration: x
    };
    return D
}

function xn(t, n, o, s, c) {
    const r = c.measure(10),
        e = c.measure(50),
        u = ot(.1, .99);
    let i = !1;

    function a() {
        return !(i || !t.reachedAny(o.get()) || !t.reachedAny(n.get()))
    }

    function h(y) {
        if (!a()) return;
        const l = t.reachedMin(n.get()) ? "min" : "max",
            m = M(t[l] - n.get()),
            g = o.get() - n.get(),
            f = u.constrain(m / e);
        o.subtract(g * f), !y && M(g) < r && (o.set(t.constrain(o.get())), s.useDuration(25).useBaseFriction())
    }

    function d(y) {
        i = !y
    }
    return {
        shouldConstrain: a,
        constrain: h,
        toggleActive: d
    }
}

function En(t, n, o, s, c) {
    const r = ot(-n + t, 0),
        e = d(),
        u = h(),
        i = p();

    function a(l, m) {
        return dt(l, m) <= 1
    }

    function h() {
        const l = e[0],
            m = z(e),
            g = e.lastIndexOf(l),
            f = e.indexOf(m) + 1;
        return ot(g, f)
    }

    function d() {
        return o.map((l, m) => {
            const {
                min: g,
                max: f
            } = r, b = r.constrain(l), x = !m, L = Mt(o, m);
            return x ? f : L || a(g, b) ? g : a(f, b) ? f : b
        }).map(l => parseFloat(l.toFixed(3)))
    }

    function p() {
        if (n <= t + c) return [r.max];
        if (s === "keepSnaps") return e;
        const {
            min: l,
            max: m
        } = u;
        return e.slice(l, m)
    }
    return {
        snapsContained: i,
        scrollContainLimit: u
    }
}

function vn(t, n, o) {
    const s = n[0],
        c = o ? s - t : z(n);
    return {
        limit: ot(c, s)
    }
}

function Ln(t, n, o, s) {
    const r = n.min + .1,
        e = n.max + .1,
        {
            reachedMin: u,
            reachedMax: i
        } = ot(r, e);

    function a(p) {
        return p === 1 ? i(o.get()) : p === -1 ? u(o.get()) : !1
    }

    function h(p) {
        if (!a(p)) return;
        const y = t * (p * -1);
        s.forEach(l => l.add(y))
    }
    return {
        loop: h
    }
}

function Tn(t) {
    const {
        max: n,
        length: o
    } = t;

    function s(r) {
        const e = r - n;
        return o ? e / -o : 0
    }
    return {
        get: s
    }
}

function In(t, n, o, s, c) {
    const {
        startEdge: r,
        endEdge: e
    } = t, {
        groupSlides: u
    } = c, i = d().map(n.measure), a = p(), h = y();

    function d() {
        return u(s).map(m => z(m)[e] - m[0][r]).map(M)
    }

    function p() {
        return s.map(m => o[r] - m[r]).map(m => -M(m))
    }

    function y() {
        return u(a).map(m => m[0]).map((m, g) => m + i[g])
    }
    return {
        snaps: a,
        snapsAligned: h
    }
}

function An(t, n, o, s, c, r) {
    const {
        groupSlides: e
    } = c, {
        min: u,
        max: i
    } = s, a = h();

    function h() {
        const p = e(r),
            y = !t || n === "keepSnaps";
        return o.length === 1 ? [r] : y ? p : p.slice(u, i).map((l, m, g) => {
            const f = !m,
                b = Mt(g, m);
            if (f) {
                const x = z(g[0]) + 1;
                return qt(x)
            }
            if (b) {
                const x = ht(r) - z(g)[0] + 1;
                return qt(x, z(g)[0])
            }
            return l
        })
    }
    return {
        slideRegistry: a
    }
}

function On(t, n, o, s, c) {
    const {
        reachedAny: r,
        removeOffset: e,
        constrain: u
    } = s;

    function i(l) {
        return l.concat().sort((m, g) => M(m) - M(g))[0]
    }

    function a(l) {
        const m = t ? e(l) : u(l),
            g = n.map((b, x) => ({
                diff: h(b - m, 0),
                index: x
            })).sort((b, x) => M(b.diff) - M(x.diff)),
            {
                index: f
            } = g[0];
        return {
            index: f,
            distance: m
        }
    }

    function h(l, m) {
        const g = [l, l + o, l - o];
        if (!t) return l;
        if (!m) return i(g);
        const f = g.filter(b => wt(b) === m);
        return f.length ? i(f) : z(g) - o
    }

    function d(l, m) {
        const g = n[l] - c.get(),
            f = h(g, m);
        return {
            index: l,
            distance: f
        }
    }

    function p(l, m) {
        const g = c.get() + l,
            {
                index: f,
                distance: b
            } = a(g),
            x = !t && r(g);
        if (!m || x) return {
            index: f,
            distance: l
        };
        const L = n[f] - b,
            D = l + h(L, 0);
        return {
            index: f,
            distance: D
        }
    }
    return {
        byDistance: p,
        byIndex: d,
        shortcut: h
    }
}

function Dn(t, n, o, s, c, r, e) {
    function u(d) {
        const p = d.distance,
            y = d.index !== n.get();
        r.add(p), p && (s.duration() ? t.start() : (t.update(), t.render(1), t.update())), y && (o.set(n.get()), n.set(d.index), e.emit("select"))
    }

    function i(d, p) {
        const y = c.byDistance(d, p);
        u(y)
    }

    function a(d, p) {
        const y = n.clone().set(d),
            l = c.byIndex(y.get(), p);
        u(l)
    }
    return {
        distance: i,
        index: a
    }
}

function wn(t, n, o, s, c, r, e, u) {
    const i = {
        passive: !0,
        capture: !0
    };
    let a = 0;

    function h(y) {
        if (!u) return;

        function l(m) {
            if (new Date().getTime() - a > 10) return;
            e.emit("slideFocusStart"), t.scrollLeft = 0;
            const b = o.findIndex(x => x.includes(m));
            Dt(b) && (c.useDuration(0), s.index(b, 0), e.emit("slideFocus"))
        }
        r.add(document, "keydown", d, !1), n.forEach((m, g) => {
            r.add(m, "focus", f => {
                (yt(u) || u(y, f)) && l(g)
            }, i)
        })
    }

    function d(y) {
        y.code === "Tab" && (a = new Date().getTime())
    }
    return {
        init: h
    }
}

function lt(t) {
    let n = t;

    function o() {
        return n
    }

    function s(i) {
        n = e(i)
    }

    function c(i) {
        n += e(i)
    }

    function r(i) {
        n -= e(i)
    }

    function e(i) {
        return Dt(i) ? i : i.get()
    }
    return {
        get: o,
        set: s,
        add: c,
        subtract: r
    }
}

function Kt(t, n) {
    const o = t.scroll === "x" ? e : u,
        s = n.style;
    let c = null,
        r = !1;

    function e(p) {
        return `translate3d(${p}px,0px,0px)`
    }

    function u(p) {
        return `translate3d(0px,${p}px,0px)`
    }

    function i(p) {
        if (r) return;
        const y = fn(t.direction(p));
        y !== c && (s.transform = o(y), c = y)
    }

    function a(p) {
        r = !p
    }

    function h() {
        r || (s.transform = "", n.getAttribute("style") || n.removeAttribute("style"))
    }
    return {
        clear: h,
        to: i,
        toggleActive: a
    }
}

function Mn(t, n, o, s, c, r, e, u, i) {
    const h = pt(c),
        d = pt(c).reverse(),
        p = f().concat(b());

    function y(E, v) {
        return E.reduce((I, P) => I - c[P], v)
    }

    function l(E, v) {
        return E.reduce((I, P) => y(I, v) > 0 ? I.concat([P]) : I, [])
    }

    function m(E) {
        return r.map((v, I) => ({
            start: v - s[I] + .5 + E,
            end: v + n - .5 + E
        }))
    }

    function g(E, v, I) {
        const P = m(v);
        return E.map(A => {
            const N = I ? 0 : -o,
                V = I ? o : 0,
                _ = I ? "end" : "start",
                R = P[A][_];
            return {
                index: A,
                loopPoint: R,
                slideLocation: lt(-1),
                translate: Kt(t, i[A]),
                target: () => u.get() > R ? N : V
            }
        })
    }

    function f() {
        const E = e[0],
            v = l(d, E);
        return g(v, o, !1)
    }

    function b() {
        const E = n - e[0] - 1,
            v = l(h, E);
        return g(v, -o, !0)
    }

    function x() {
        return p.every(({
            index: E
        }) => {
            const v = h.filter(I => I !== E);
            return y(v, n) <= .1
        })
    }

    function L() {
        p.forEach(E => {
            const {
                target: v,
                translate: I,
                slideLocation: P
            } = E, A = v();
            A !== P.get() && (I.to(A), P.set(A))
        })
    }

    function D() {
        p.forEach(E => E.translate.clear())
    }
    return {
        canLoop: x,
        clear: D,
        loop: L,
        loopPoints: p
    }
}

function Pn(t, n, o) {
    let s, c = !1;

    function r(i) {
        if (!o) return;

        function a(h) {
            for (const d of h)
                if (d.type === "childList") {
                    i.reInit(), n.emit("slidesChanged");
                    break
                }
        }
        s = new MutationObserver(h => {
            c || (yt(o) || o(i, h)) && a(h)
        }), s.observe(t, {
            childList: !0
        })
    }

    function e() {
        s && s.disconnect(), c = !0
    }
    return {
        init: r,
        destroy: e
    }
}

function jn(t, n, o, s) {
    const c = {};
    let r = null,
        e = null,
        u, i = !1;

    function a() {
        u = new IntersectionObserver(l => {
            i || (l.forEach(m => {
                const g = n.indexOf(m.target);
                c[g] = m
            }), r = null, e = null, o.emit("slidesInView"))
        }, {
            root: t.parentElement,
            threshold: s
        }), n.forEach(l => u.observe(l))
    }

    function h() {
        u && u.disconnect(), i = !0
    }

    function d(l) {
        return mt(c).reduce((m, g) => {
            const f = parseInt(g),
                {
                    isIntersecting: b
                } = c[f];
            return (l && b || !l && !b) && m.push(f), m
        }, [])
    }

    function p(l = !0) {
        if (l && r) return r;
        if (!l && e) return e;
        const m = d(l);
        return l && (r = m), l || (e = m), m
    }
    return {
        init: a,
        destroy: h,
        get: p
    }
}

function Fn(t, n, o, s, c, r) {
    const {
        measureSize: e,
        startEdge: u,
        endEdge: i
    } = t, a = o[0] && c, h = l(), d = m(), p = o.map(e), y = g();

    function l() {
        if (!a) return 0;
        const b = o[0];
        return M(n[u] - b[u])
    }

    function m() {
        if (!a) return 0;
        const b = r.getComputedStyle(z(s));
        return parseFloat(b.getPropertyValue(`margin-${i}`))
    }

    function g() {
        return o.map((b, x, L) => {
            const D = !x,
                T = Mt(L, x);
            return D ? p[x] + h : T ? p[x] + d : L[x + 1][u] - b[u]
        }).map(M)
    }
    return {
        slideSizes: p,
        slideSizesWithGaps: y,
        startGap: h,
        endGap: d
    }
}

function Cn(t, n, o, s, c, r, e, u, i) {
    const {
        startEdge: a,
        endEdge: h,
        direction: d
    } = t, p = Dt(o);

    function y(f, b) {
        return pt(f).filter(x => x % b === 0).map(x => f.slice(x, x + b))
    }

    function l(f) {
        return f.length ? pt(f).reduce((b, x, L) => {
            const D = z(b) || 0,
                T = D === 0,
                E = x === ht(f),
                v = c[a] - r[D][a],
                I = c[a] - r[x][h],
                P = !s && T ? d(e) : 0,
                A = !s && E ? d(u) : 0,
                N = M(I - A - (v + P));
            return L && N > n + i && b.push(x), E && b.push(f.length), b
        }, []).map((b, x, L) => {
            const D = Math.max(L[x - 1] || 0);
            return f.slice(D, b)
        }) : []
    }

    function m(f) {
        return p ? y(f, o) : l(f)
    }
    return {
        groupSlides: m
    }
}

function Nn(t, n, o, s, c, r, e) {
    const {
        align: u,
        axis: i,
        direction: a,
        startIndex: h,
        loop: d,
        duration: p,
        dragFree: y,
        dragThreshold: l,
        inViewThreshold: m,
        slidesToScroll: g,
        skipSnaps: f,
        containScroll: b,
        watchResize: x,
        watchSlides: L,
        watchDrag: D,
        watchFocus: T
    } = r, E = 2, v = hn(), I = v.measure(n), P = o.map(v.measure), A = pn(i, a), N = A.measureSize(I), V = bn(N), _ = ln(u, N), R = !d && !!b, Z = d || !!b, {
        slideSizes: W,
        slideSizesWithGaps: q,
        startGap: $,
        endGap: ct
    } = Fn(A, I, P, o, Z, c), G = Cn(A, N, g, d, I, P, $, ct, E), {
        snaps: rt,
        snapsAligned: st
    } = In(A, _, I, P, G), U = -z(rt) + z(q), {
        snapsContained: ut,
        scrollContainLimit: at
    } = En(N, U, st, b, E), k = R ? ut : st, {
        limit: F
    } = vn(U, k, d), K = Ut(ht(k), h, d), B = K.clone(), w = pt(o), S = ({
        dragHandler: it,
        scrollBody: Lt,
        scrollBounds: Tt,
        options: {
            loop: bt
        }
    }) => {
        bt || Tt.constrain(it.pointerDown()), Lt.seek()
    }, O = ({
        scrollBody: it,
        translate: Lt,
        location: Tt,
        offsetLocation: bt,
        previousLocation: Xt,
        scrollLooper: Yt,
        slideLooper: Zt,
        dragHandler: tn,
        animation: nn,
        eventHandler: Ct,
        scrollBounds: en,
        options: {
            loop: Nt
        }
    }, kt) => {
        const Bt = it.settled(),
            on = !en.shouldConstrain(),
            zt = Nt ? Bt : Bt && on;
        zt && !tn.pointerDown() && (nn.stop(), Ct.emit("settle")), zt || Ct.emit("scroll");
        const rn = Tt.get() * kt + Xt.get() * (1 - kt);
        bt.set(rn), Nt && (Yt.loop(it.direction()), Zt.loop()), Lt.to(bt.get())
    }, j = dn(s, c, () => S(vt), it => O(vt, it)), C = .68, H = k[K.get()], Q = lt(H), tt = lt(H), X = lt(H), nt = lt(H), ft = yn(Q, X, tt, nt, p, C), xt = On(d, k, U, F, nt), Et = Dn(j, K, B, ft, xt, nt, e), Pt = Tn(F), jt = gt(), Jt = jn(n, o, e, m), {
        slideRegistry: Ft
    } = An(R, b, k, at, G, w), Wt = wn(t, o, Ft, Et, ft, jt, e, T), vt = {
        ownerDocument: s,
        ownerWindow: c,
        eventHandler: e,
        containerRect: I,
        slideRects: P,
        animation: j,
        axis: A,
        dragHandler: mn(A, t, s, c, nt, gn(A, c), Q, j, Et, ft, xt, K, e, V, y, l, f, C, D),
        eventStore: jt,
        percentOfView: V,
        index: K,
        indexPrevious: B,
        limit: F,
        location: Q,
        offsetLocation: X,
        previousLocation: tt,
        options: r,
        resizeHandler: Sn(n, e, c, o, A, x, v),
        scrollBody: ft,
        scrollBounds: xn(F, X, nt, ft, V),
        scrollLooper: Ln(U, F, X, [Q, X, tt, nt]),
        scrollProgress: Pt,
        scrollSnapList: k.map(Pt.get),
        scrollSnaps: k,
        scrollTarget: xt,
        scrollTo: Et,
        slideLooper: Mn(A, N, U, W, q, rt, k, X, o),
        slideFocus: Wt,
        slidesHandler: Pn(n, e, L),
        slidesInView: Jt,
        slideIndexes: w,
        slideRegistry: Ft,
        slidesToScroll: G,
        target: nt,
        translate: Kt(A, n)
    };
    return vt
}

function kn() {
    let t = {},
        n;

    function o(a) {
        n = a
    }

    function s(a) {
        return t[a] || []
    }

    function c(a) {
        return s(a).forEach(h => h(n, a)), i
    }

    function r(a, h) {
        return t[a] = s(a).concat([h]), i
    }

    function e(a, h) {
        return t[a] = s(a).filter(d => d !== h), i
    }

    function u() {
        t = {}
    }
    const i = {
        init: o,
        emit: c,
        off: e,
        on: r,
        clear: u
    };
    return i
}
const Bn = {
    align: "center",
    axis: "x",
    container: null,
    slides: null,
    containScroll: "trimSnaps",
    direction: "ltr",
    slidesToScroll: 1,
    inViewThreshold: 0,
    breakpoints: {},
    dragFree: !1,
    dragThreshold: 10,
    loop: !1,
    skipSnaps: !1,
    duration: 25,
    startIndex: 0,
    active: !0,
    watchDrag: !0,
    watchResize: !0,
    watchSlides: !0,
    watchFocus: !0
};

function zn(t) {
    function n(r, e) {
        return $t(r, e || {})
    }

    function o(r) {
        const e = r.breakpoints || {},
            u = mt(e).filter(i => t.matchMedia(i).matches).map(i => e[i]).reduce((i, a) => n(i, a), {});
        return n(r, u)
    }

    function s(r) {
        return r.map(e => mt(e.breakpoints || {})).reduce((e, u) => e.concat(u), []).map(t.matchMedia)
    }
    return {
        mergeOptions: n,
        optionsAtMedia: o,
        optionsMediaQueries: s
    }
}

function Vn(t) {
    let n = [];

    function o(r, e) {
        return n = e.filter(({
            options: u
        }) => t.optionsAtMedia(u).active !== !1), n.forEach(u => u.init(r, t)), e.reduce((u, i) => Object.assign(u, {
            [i.name]: i
        }), {})
    }

    function s() {
        n = n.filter(r => r.destroy())
    }
    return {
        init: o,
        destroy: s
    }
}

function St(t, n, o) {
    const s = t.ownerDocument,
        c = s.defaultView,
        r = zn(c),
        e = Vn(r),
        u = gt(),
        i = kn(),
        {
            mergeOptions: a,
            optionsAtMedia: h,
            optionsMediaQueries: d
        } = r,
        {
            on: p,
            off: y,
            emit: l
        } = i,
        m = A;
    let g = !1,
        f, b = a(Bn, St.globalOptions),
        x = a(b),
        L = [],
        D, T, E;

    function v() {
        const {
            container: w,
            slides: S
        } = x;
        T = (It(w) ? t.querySelector(w) : w) || t.children[0];
        const j = It(S) ? T.querySelectorAll(S) : S;
        E = [].slice.call(j || T.children)
    }

    function I(w) {
        const S = Nn(t, T, E, s, c, w, i);
        if (w.loop && !S.slideLooper.canLoop()) {
            const O = Object.assign({}, w, {
                loop: !1
            });
            return I(O)
        }
        return S
    }

    function P(w, S) {
        g || (b = a(b, w), x = h(b), L = S || L, v(), f = I(x), d([b, ...L.map(({
            options: O
        }) => O)]).forEach(O => u.add(O, "change", A)), x.active && (f.translate.to(f.location.get()), f.animation.init(), f.slidesInView.init(), f.slideFocus.init(B), f.eventHandler.init(B), f.resizeHandler.init(B), f.slidesHandler.init(B), f.options.loop && f.slideLooper.loop(), T.offsetParent && E.length && f.dragHandler.init(B), D = e.init(B, L)))
    }

    function A(w, S) {
        const O = G();
        N(), P(a({
            startIndex: O
        }, w), S), i.emit("reInit")
    }

    function N() {
        f.dragHandler.destroy(), f.eventStore.clear(), f.translate.clear(), f.slideLooper.clear(), f.resizeHandler.destroy(), f.slidesHandler.destroy(), f.slidesInView.destroy(), f.animation.destroy(), e.destroy(), u.clear()
    }

    function V() {
        g || (g = !0, u.clear(), N(), i.emit("destroy"), i.clear())
    }

    function _(w, S, O) {
        !x.active || g || (f.scrollBody.useBaseFriction().useDuration(S === !0 ? 0 : x.duration), f.scrollTo.index(w, O || 0))
    }

    function R(w) {
        const S = f.index.add(1).get();
        _(S, w, -1)
    }

    function Z(w) {
        const S = f.index.add(-1).get();
        _(S, w, 1)
    }

    function W() {
        return f.index.add(1).get() !== G()
    }

    function q() {
        return f.index.add(-1).get() !== G()
    }

    function $() {
        return f.scrollSnapList
    }

    function ct() {
        return f.scrollProgress.get(f.location.get())
    }

    function G() {
        return f.index.get()
    }

    function rt() {
        return f.indexPrevious.get()
    }

    function st() {
        return f.slidesInView.get()
    }

    function U() {
        return f.slidesInView.get(!1)
    }

    function ut() {
        return D
    }

    function at() {
        return f
    }

    function k() {
        return t
    }

    function F() {
        return T
    }

    function K() {
        return E
    }
    const B = {
        canScrollNext: W,
        canScrollPrev: q,
        containerNode: F,
        internalEngine: at,
        destroy: V,
        off: y,
        on: p,
        emit: l,
        plugins: ut,
        previousScrollSnap: rt,
        reInit: m,
        rootNode: k,
        scrollNext: R,
        scrollPrev: Z,
        scrollProgress: ct,
        scrollSnapList: $,
        scrollTo: _,
        selectedScrollSnap: G,
        slideNodes: K,
        slidesInView: st,
        slidesNotInView: U
    };
    return P(n, o), setTimeout(() => i.emit("init"), 0), B
}
St.globalOptions = void 0;

function Qt(t = {}, n = []) {
    const o = J.useRef(t),
        s = J.useRef(n),
        [c, r] = J.useState(),
        [e, u] = J.useState(),
        i = J.useCallback(() => {
            c && c.reInit(o.current, s.current)
        }, [c]);
    return J.useEffect(() => {
        Ot(o.current, t) || (o.current = t, i())
    }, [t, i]), J.useEffect(() => {
        un(s.current, n) || (s.current = n, i())
    }, [n, i]), J.useEffect(() => {
        if (cn() && e) {
            St.globalOptions = Qt.globalOptions;
            const a = St(e, o.current, s.current);
            return r(a), () => a.destroy()
        } else r(void 0)
    }, [e, r]), [u, c]
}
Qt.globalOptions = void 0;
const _n = "_navigationBar_rzc5j_23",
    Rn = "_dotsWrapper_rzc5j_30",
    Gn = "_active_rzc5j_43",
    Hn = "_arrowWrapper_rzc5j_47",
    qn = "_disabled_rzc5j_71",
    et = {
        navigationBar: _n,
        dotsWrapper: Rn,
        active: Gn,
        arrowWrapper: Hn,
        disabled: qn
    },
    Qn = ({
        itemsLength: t,
        className: n,
        currentIndex: o,
        onPrev: s,
        onNext: c
    }) => {
        const r = J.useRef(null);
        return Y.jsxs("div", {
            ref: r,
            className: Vt(et.navigationBar, n),
            children: [Y.jsx("ul", {
                className: et.dotsWrapper,
                children: [...Array(t)].map((e, u) => Y.jsx("li", {
                    className: Vt(et.dot, {
                        [et.active]: o === u
                    })
                }, u))
            }), Y.jsxs("div", {
                className: et.arrowWrapper,
                children: [Y.jsx("button", {
                    type: "button",
                    "aria-label": "Previous slide",
                    className: o === 0 ? et.disabled : "",
                    onClick: s,
                    children: Y.jsx(_t, {})
                }), Y.jsx("button", {
                    type: "button",
                    "aria-label": "Next slide",
                    className: o === t - 1 ? et.disabled : "",
                    onClick: c,
                    children: Y.jsx(_t, {})
                })]
            })]
        })
    };
export {
    Qn as N, Qt as u
};