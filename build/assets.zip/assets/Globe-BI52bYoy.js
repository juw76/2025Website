import {
    j as a
} from "./client-DVrblGvH.js";
import {
    c as d
} from "./clsx-B-dksMZM.js";
import {
    u as c
} from "./Video-BBuaToM0.js";
const b = "_globeWrapper_1t7y0_23",
    g = "_Point_1t7y0_29",
    i = "_globeContent_1t7y0_38",
    l = {
        globeWrapper: b,
        Point: g,
        globeContent: i
    },
    p = ({
        points: t,
        scale: o = 1,
        fadeY: r = 0,
        className: s = ""
    }) => {
        const {
            add: n
        } = c();
        return a.jsx("div", {
            className: l.globeWrapper,
            children: a.jsx("div", {
                ref: n("globe", 0),
                className: d(l.globeContent, s),
                "data-object": "globe",
                "data-scale": o,
                "data-fade-y": r,
                children: t == null ? void 0 : t.map(e => a.jsx("div", {
                    "data-point": !0,
                    className: l.Point,
                    "data-latitude": e.latitude,
                    "data-longitude": e.longitude,
                    children: e.label
                }, e.label))
            })
        })
    };
export {
    p as G
};